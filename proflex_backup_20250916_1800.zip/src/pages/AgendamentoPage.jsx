import React from "react";
import NovoAgendamento from "../components/NovoAgendamento.jsx";

export default function AgendamentoPage() {
  return <NovoAgendamento />;
}
