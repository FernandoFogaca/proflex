export const COMORBIDADES = [
  "Hipertensão","Diabetes","Asma","Cardiopatia",
  "Doença Renal","Obesidade","Tabagismo","Gestação",
];
